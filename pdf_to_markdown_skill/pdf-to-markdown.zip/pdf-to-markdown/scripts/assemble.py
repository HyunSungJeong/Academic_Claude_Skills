#!/usr/bin/env python3
"""Join per-page Markdown files into the final document and lay out its companion figures.

usage: assemble.py WORKDIR/md OUTDIR --name NAME [--figures DIR]

NAME is the original PDF's file name without ".pdf", unchanged. Writes
    OUTDIR/NAME.md          the text-only document (no image data inside)
    OUTDIR/NAME_figN.png    one companion file per figure (or .jpg)

Pages: page_NNN.md files are concatenated in page order, separated by a blank
line. A page file whose last line is exactly  <!-- continues -->  ends
mid-paragraph: the marker is removed and the next page's first line is joined
to it with a single space, so a paragraph broken by a page break comes out whole.

Figures: each placeholder  ![Fig. N](figure:figN)  becomes a relative link to the
companion file,  ![Fig. N](<NAME_figN.png>),  and the image (from figures.py, in
DIR, default the 'figures' folder next to the md folder) is copied to OUTDIR
under that name. The Markdown therefore stays small and fully readable as text,
the link names the exact companion file, and in a folder that holds both, a
Markdown viewer shows the figure. A missing figure is an error.
"""
import sys, os, re, glob, shutil, argparse
ap = argparse.ArgumentParser(); ap.add_argument('src'); ap.add_argument('outdir')
ap.add_argument('--name', required=True); ap.add_argument('--figures')
a = ap.parse_args()
if a.name.lower().endswith('.pdf'): a.name = a.name[:-4]
figdir = a.figures or os.path.join(os.path.dirname(os.path.abspath(a.src)), 'figures')
files = sorted(glob.glob(os.path.join(a.src, 'page_*.md')), key=lambda f: int(re.search(r'page_(\d+)', f).group(1)))
if not files: sys.exit(f'no page_NNN.md files in {a.src}')
doc, joined = '', 0
for f in files:
    t = open(f).read().strip('\n')
    if doc.endswith('<!-- continues -->'):
        doc = doc[:-len('<!-- continues -->')].rstrip() + ' ' + t.lstrip(); joined += 1
    else:
        doc = (doc + '\n\n' + t) if doc else t
if doc.endswith('<!-- continues -->'): doc = doc[:-len('<!-- continues -->')].rstrip()

os.makedirs(a.outdir, exist_ok=True)
copied, missing = [], []
def link(m):
    alt, fig = m.group(1), m.group(2)
    for ext in ('png', 'jpg'):
        p = os.path.join(figdir, f'{fig}.{ext}')
        if os.path.exists(p):
            target = f'{a.name}_{fig}.{ext}'
            shutil.copyfile(p, os.path.join(a.outdir, target)); copied.append(target)
            return f'![{alt}](<{target}>)'
    missing.append(fig); return m.group(0)
doc = re.sub(r'!\[([^\]]*)\]\(figure:([\w.-]+)\)', link, doc)
if missing: sys.exit(f'figure(s) not found in {figdir}: {missing}')
if re.search(r'data:image/', doc): sys.exit('image data found in the Markdown; figures must be placeholders')
out = os.path.join(a.outdir, f'{a.name}.md')
open(out, 'w').write(doc + '\n')
print(f'{len(files)} pages -> {out} ({os.path.getsize(out)//1024} KB, text only; {joined} paragraph(s) joined across page breaks)')
for c in copied: print(f'   companion: {os.path.join(a.outdir, c)} ({os.path.getsize(os.path.join(a.outdir, c))//1024} KB)')

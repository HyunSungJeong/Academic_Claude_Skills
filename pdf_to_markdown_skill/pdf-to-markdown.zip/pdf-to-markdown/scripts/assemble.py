#!/usr/bin/env python3
"""Join per-page Markdown files into the final document without retyping anything.

usage: assemble.py WORKDIR/md OUTPUT.md

Concatenates page_NNN.md in page order, separated by a blank line. A page file
whose last line is exactly  <!-- continues -->  ends mid-paragraph: the marker is
removed and the next page's first line is joined to it with a single space, so a
paragraph broken by a page break comes out whole. (A word hyphenated across the
break should already be written whole on the earlier page.)
"""
import sys, os, re, glob
src, out = sys.argv[1], sys.argv[2]
files = sorted(glob.glob(os.path.join(src, 'page_*.md')), key=lambda f: int(re.search(r'page_(\d+)', f).group(1)))
if not files: sys.exit(f'no page_NNN.md files in {src}')
doc, joined = '', 0
for f in files:
    t = open(f).read().strip('\n')
    if doc.endswith('<!-- continues -->'):
        doc = doc[:-len('<!-- continues -->')].rstrip() + ' ' + t.lstrip(); joined += 1
    else:
        doc = (doc + '\n\n' + t) if doc else t
if doc.endswith('<!-- continues -->'): doc = doc[:-len('<!-- continues -->')].rstrip()
open(out, 'w').write(doc + '\n')
print(f'{len(files)} pages -> {out} ({len(doc)} chars; {joined} paragraph(s) joined across page breaks)')

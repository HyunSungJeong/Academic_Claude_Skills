#!/usr/bin/env python3
"""Join per-page Markdown files into one self-contained document without retyping anything.

usage: assemble.py WORKDIR/md OUTPUT.md [--figures DIR]

Concatenates page_NNN.md in page order, separated by a blank line. A page file
whose last line is exactly  <!-- continues -->  ends mid-paragraph: the marker is
removed and the next page's first line is joined to it with a single space, so a
paragraph broken by a page break comes out whole. (A word hyphenated across the
break should already be written whole on the earlier page.)

Figure placeholders  ![caption label](figure:NAME)  are replaced by the image
DIR/NAME.png or DIR/NAME.jpg (written by figures.py), embedded as a base64 data
URI, so the output is a single file with no external dependencies. DIR defaults
to the 'figures' folder next to the md folder. A missing figure is an error.
"""
import sys, os, re, glob, base64, argparse
ap = argparse.ArgumentParser(); ap.add_argument('src'); ap.add_argument('out'); ap.add_argument('--figures')
a = ap.parse_args()
figdir = a.figures or os.path.join(os.path.dirname(os.path.abspath(a.src)), 'figures')
files = sorted(glob.glob(os.path.join(a.src, 'page_*.md')), key=lambda f: int(re.search(r'page_(\d+)', f).group(1)))
if not files: sys.exit(f'no page_NNN.md files in {a.src}')
doc, joined = '', 0
for f in files:
    t = open(f).read().strip('\n')
    if doc.endswith('<!-- continues -->'):
        doc = doc[:-len('<!-- continues -->')].rstrip() + ' ' + t.lstrip(); joined += 1
    else:
        doc = (doc + '\n\n' + t) if doc else t
if doc.endswith('<!-- continues -->'): doc = doc[:-len('<!-- continues -->')].rstrip()

embedded, missing = [], []
def embed(m):
    alt, name = m.group(1), m.group(2)
    for ext, mime in (('png', 'image/png'), ('jpg', 'image/jpeg')):
        p = os.path.join(figdir, f'{name}.{ext}')
        if os.path.exists(p):
            embedded.append(name)
            return f'![{alt}](data:{mime};base64,{base64.b64encode(open(p, "rb").read()).decode()})'
    missing.append(name); return m.group(0)
doc = re.sub(r'!\[([^\]]*)\]\(figure:([\w.-]+)\)', embed, doc)
if missing: sys.exit(f'figure(s) not found in {figdir}: {missing}')
open(a.out, 'w').write(doc + '\n')
print(f'{len(files)} pages -> {a.out} ({os.path.getsize(a.out)//1024} KB; {joined} paragraph(s) joined across '
      f'page breaks; {len(embedded)} figure(s) embedded)')

---
name: pdf-to-markdown
description: Convert a PDF (papers, notes, textbooks with equations) to Markdown with exact LaTeX math, transcribed from page images and machine-checked. Use when asked to convert a PDF to .md.
metadata:
  version: "2.2"
---

# PDF → Markdown with exact math

`SKILL_DIR` below is this skill's folder (usually `/mnt/skills/user/pdf-to-markdown`).
Work in `/home/claude/work`; the final file goes to `/mnt/user-data/outputs/<name>.md`.

## Ground rules (learned from testing)

- **Never take mathematics from the text layer.** It merges calligraphic/roman/bold
  (𝒢 → G, **ω** → ω), detaches accents (K̃ came out as `K = 1 ˜ /Ω`), flattens
  sub/superscripts, and leaks `(cid:NN)` for ∫ ∑ and braces. Every formula,
  inline or displayed, is transcribed from the page image.
- **Do not use markitdown on PDFs.** On a LaTeX PDF it invented tables out of
  ordinary sentences.
- **Do not read the text layer.** Prose read from the strips is reliable. When one
  word is doubtful, `grep` for it in `page_NNN.txt`; never `cat` or `view` a whole
  page of it.
- **Every token of output is written once.** Each page goes to its own file;
  the document is joined by a script; corrections are targeted edits. Never
  re-output the document or a page in the chat or in a new file.
- **If the LaTeX source exists, use it instead** (`pandoc -f latex -t markdown`),
  then fix `\bm`→`\boldsymbol`, drop `\label`, add `\tag{}`s and the title/abstract.

## Steps

1. `pip install pymupdf --break-system-packages -q` (if missing), then
   `python3 SKILL_DIR/scripts/prepare.py INPUT.pdf /home/claude/work`.
   It renders 170 dpi strips `page_NNN_sKK.png`, cut between lines, and prints
   one line per page: whether the page needs images (`img`) or may come from the
   text layer (`text-ok`, no math fonts at all), each strip with its y-range in
   points, and the printed equation tags. That printout is all you need; do not
   open `manifest.json` (the check scripts read it).
2. For each page, `view` its strips in order and write that page's Markdown with
   `create_file` to `/home/claude/work/md/page_NNN.md` (three-digit page number).
   Where a symbol is small or ambiguous, render a zoom (500–600 dpi) of just that
   region: `page.get_pixmap(dpi=600, clip=pymupdf.Rect(x0,y0,x1,y1))`, coordinates
   in points as printed by `prepare.py`. Always zoom for: bars spanning several
   characters (`\overline{i+1}` vs `\bar i+1`), tildes and hats, primes, which
   terms an under/overbrace covers (including a leading minus sign), bold vs not
   bold, and calligraphic vs roman vs italic letters.
3. Writing conventions:
   - Inline `$...$`, display `$$ ... \tag{N} $$` using the **printed** number
     (tags can be out of sequence, e.g. (33) after (8)). Display blocks on their
     own lines, blank line before and after.
   - Reproduce typeface exactly: `\mathcal{G}`, `\mathrm{G}`, `\boldsymbol\omega`,
     upright `\mathrm i`, `\mathrm d`, `\mathrm e` when the PDF prints them upright.
   - Only KaTeX/MathJax-compatible commands; no custom macros. `\boxed{}`,
     `\underbrace{}_{}`, `\begin{cases}` and `\tag{}` are fine.
   - Headings as `#`/`##`/`###`; bold run-in paragraph heads as `**...**`.
   - A page that ends mid-paragraph ends its file with the line
     `<!-- continues -->`; the next file starts with the rest of the sentence.
     A word hyphenated across the break is written whole on the earlier page.
   - Reproduce the document as printed, including apparent typos; do not correct.
4. Join the pages, then run the mechanical checks:
   `python3 SKILL_DIR/scripts/assemble.py /home/claude/work/md /home/claude/work/OUT.md`
   `python3 SKILL_DIR/scripts/check.py /home/claude/work/OUT.md /home/claude/work/manifest.json`
   (KaTeX syntax of every formula; every printed equation tag present exactly
   once; no text-layer debris such as `(cid:NN)`). Fix each finding with
   `str_replace` on `OUT.md`; do not rewrite the file.
5. Proofread displayed equations:
   `python3 SKILL_DIR/scripts/verify_eqs.py /home/claude/work/OUT.md /home/claude/work`
   Read its full printout first: any `PROBLEM` line is an equation that is not on
   the sheets and must be fixed. Then `view` each `verify/sheet_NN.png`. Each
   panel shows the PDF crop (top) and the re-typeset transcription (bottom).
   Compare symbol by symbol and fix any difference with `str_replace`. Inline
   math is not covered by the sheets: re-read it on the strips for any line with
   indices or accents.
6. Copy `OUT.md` to `/mnt/user-data/outputs/<name>.md` and present it. Report in
   one or two lines: pages done, check results, and any symbol left ambiguous
   (say where).

## Budget

Each strip or zoom costs context: a 170 dpi strip is about 600 tokens, so a
page of 4–5 strips is about 2,500–3,000 tokens, plus zooms and the proofreading
sheets (about 1,500 tokens each, four equations per sheet). A 10-page note fits
easily; for a long paper or book, convert one chapter or section per
conversation and say so up front.

## Regression test (when a .tex is available)

`scripts/eval/mathcmp.py SOURCE.tex OUT.md [--lenient]` compares every display
and inline formula token by token (after expanding zero-argument `\newcommand`s;
`--lenient` also forgives upright vs italic i, d, e). Count exact matches only;
the mean similarity stays high even when formulas are wrong. It works on any
tool's Markdown output, not just this skill's;
`scripts/eval/prosecmp.py SOURCE.tex OUT.md` compares prose word by word.
Remaining differences are often spelling-only (`F_{\rm rest}` vs
`F_\mathrm{rest}`, `$\Rightarrow$` vs `⇒`); judge each one.
